<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\PurchaseDetails;
use Faker\Generator as Faker;

$factory->define(PurchaseDetails::class, function (Faker $faker) {
    return [
        //
    ];
});
