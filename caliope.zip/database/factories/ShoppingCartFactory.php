<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ShoppingCart;
use Faker\Generator as Faker;

$factory->define(ShoppingCart::class, function (Faker $faker) {
    return [
        //
    ];
});
