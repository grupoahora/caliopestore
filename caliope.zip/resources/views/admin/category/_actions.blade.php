<a class="jsgrid-button jsgrid-edit-button" href="{{route('products.show', $id)}}" title="ver detalles" target="_blank">
    <i class="far fa-eye"></i>Ver Detalles
</a>