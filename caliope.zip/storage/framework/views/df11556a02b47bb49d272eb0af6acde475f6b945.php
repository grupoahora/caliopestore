
<?php $__env->startSection('meta_description', ''); ?>
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- breadcrumb area start -->
<div class="breadcrumb-area">
    <div class="container-fluid">
        <div class="row mx-5">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('web.welcome')); ?>">Inicio</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('web.shop_grid')); ?>">Tienda</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Detalles de <?php echo e($subcategory->name); ?></li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb area end -->

<!-- product details wrapper start -->
<div class="product-details-wrapper">
    <div class="container-fluid">
        <div class="row mx-5">
            <div class="col-lg-10">
                <!-- product details inner end -->
                <div class="product-details-inner">
                    <div class="row">
                        <div class="col-lg-4" id="imgs">
                            <div class="pro-nav slick-padding2 slick-arrow-style_2">
                                <?php $__currentLoopData = $subcategory->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="pro-nav-thumb "><img width="98px" height="98px" src="<?php echo e($image->url); ?>"
                                    alt="<?php echo e($product->name); ?>" /></div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="product-large-slider mb-20 slick-arrow-style_2">
                                <?php $__currentLoopData = $subcategory->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="pro-large-img img-zoom" id="img<?php echo e($image->id); ?>">
                                    <img src="<?php echo e($image->url); ?>" alt="<?php echo e($product->name); ?>" />
                                </div>
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            
                            
                        </div>
                        <div class="col-lg-8">
                            <div class="product-details-des mt-md-34 mt-sm-34">
                                <h3 ><a href="<?php echo e(route('web.subcategory_details', $subcategory)); ?>"><?php echo e($subcategory->name); ?></a></h3>
                                
                                    <div class="py-2" id="productdetail_id">
                                            
                                                
                                    </div>
                                   
                                
                                
                                
                                
                                
                                <p><?php echo e($subcategory->description); ?></p>
                                
                                    <h5>Texturas:</h5>
                                    
                                <div class="feature-category-area mt-md-70">
                                    <div class="latest-product-active slick-padding slick-arrow-style">
                                        <?php $__currentLoopData = $subcategory->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="col-lg-12 col-md-4 col-sm-6">
                                                <div class="product-item fix mb-30">
                                                    <div class="product-thumb">
                                                        <button class="pro-nav-thumb<?php echo e($product->id); ?> border border-0 bg-transparent" id="product_id" value="<?php echo e($product->id); ?>">
                                            
                                                            
                                                            <?php $__currentLoopData = $product->textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <img width="150px" height="150px" src="<?php echo e($image->url); ?>" class="<?php if($loop->first): ?> img-pri <?php else: ?> img-sec <?php endif; ?>" alt="<?php echo e($product->name); ?>">
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                               
                                                                
                                                            
                                                            
                                                        </button>
                                                    </div>
                                                    <?php $__env->startPush('scripts'); ?>
                                                    
                                                <script>
                                                    var product = $('.pro-nav-thumb<?php echo e($product->id); ?>');
                                                    /* console.log(product); */
                                                    var productdetail = $('#productdetail_id');
                                                    var imgs = $('#imgs');
                                                    var imgs2 =   $('#imgs2');
                                                    var envio = product.click(function(){
                                                        var productval = $('.pro-nav-thumb<?php echo e($product->id); ?>').val();
                                                        var urlproducdetail = "<?php echo e(route('web.product_details', $product)); ?>";
                                                        var imgidvisible = $('div#img<?php echo e($product->images->pluck('id')[0]); ?>.pro-large-img.img-zoom.slick-slide.slick-current.slick-active');
                                                        console.log(imgidvisible);
                                                        var imgidinvisible = $('#img<?php echo e($product->images->pluck('id')[0]); ?>.pro-large-img.img-zoom.slick-slide');
                                                        if (imgidvisible.length) {
                                                            imgidvisible.removeClass('slick-current slick-active');
                                                            imgidinvisible.addClass('slick-current slick-active'); 
                                                            /* $('#img<?php echo e($product->images->pluck('id')[0]); ?>').removeClass('.slick-current.slick-active'); */
                                                            console.log('a');  
                                                            
                                                        } else if (imgidinvisible.length) {
                                                            imgidinvisible.addClass('slick-current slick-active');
                                                            imgidvisible.removeClass('slick-current slick-active');
                                                            console.log('aa'); 
                                                        }else{
                                                            console.log('b');  
                                                        }
                                                        
                                                        $.ajax({
                                                            url: "<?php echo e(route('get_product_by_product')); ?>",
                                                            method: 'GET',
                                                            data: {
                                                                product: productval,
                                                            },
                                                            
                                                            success: function(data){
                                                                productdetail.empty();
                                                                /* productdetail.append('<input type="text" value="seleccione una textura">'); */
                                                                $.each(data, function(index, element){
                                                                    productdetail.append('<h3><a href='+'"'+ urlproducdetail+ '">' + element.name +'</a>'+'</h3>');
                                                                });
                                                                
                                                            },
                                                            
                                                        });
                                                       
                                                        
                                                    });
                                                    /* console.log(envio); */
                                                </script>
                                                
                                                <?php $__env->stopPush(); ?>
                                            
                                                <div class="ratings">
                                                    <input id="input_rate_<?php echo e($product->id); ?>" name="rate" value="<?php echo e($product->AverageRating); ?>" class="rating-loading">
                                                    <?php $__env->startPush('scripts'); ?>
                                                    <script>
                                                        $(document).ready(function(){
                                                            $('#input_rate_<?php echo e($product->id); ?>').rating({
                                                                min: 0,
                                                                max: 5,
                                                                theme: 'krajee-fa', 
                                                                displayOnly: true,
                                                                step: 1, 
                                                                language: 'es',
                                                                size: 'xs', 
                                                                stars: 5,
                                                                showCaption: false,
                                                            });
                                                        });
                                                    </script>
                                                    <?php $__env->stopPush(); ?>
                                                    <?php $__env->startPush('modal'); ?>
                                                        <div class="modal fade" id="modal-default">
                                                            <div class="modal-dialog">
                                                                <div class="modal-content rounded-0">
                                                                    <div class="modal-header">
                                                                        <h4 class="modal-title my-3">Editar Dirección</h4>
                                                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                            <span aria-hidden="true">×</span>
                                                                        </button>
                                                                    </div>
                                                                    <?php echo Form::open(['route'=>['web.rate_product', $product], 'method'=>'POST']); ?>

                                                                    <div class="modal-body">
                                                                        
                                                                        <div class="single-input-item">
                                                                            <label class="col-form-label">
                                                                                <span class="text-danger">*</span> 
                                                                                Calificación general
                                                                            </label>
                                                                            <div class="form-group">
                                                                                
                                                                                <input id="input-1" name="rate" value="" class="rating-loading">
                                                                            </div>
                                                        
                                                                        </div>
                                                                        <div class="single-input-item">
                                                                            <label class="col-form-label"><span class="text-danger">*</span>Comentario</label>
                                                                            <textarea class="form-control" name="comment" required></textarea>
                                                                            
                                                                        </div>
                                                                        

                                                                                

                                                                    </div>
                                                                    <div class="modal-footer justify-content-between">
                                                                        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                                                                        <button type="submit" class="check-btn sqr-btn">Guardar cambios</button>
                                                                    </div>
                                                                    <?php echo Form::close(); ?>

                                                                </div>
                                                                <!-- /.modal-content -->
                                                            </div>
                                                            <!-- /.modal-dialog -->
                                                        </div>
                                                    <?php $__env->stopPush(); ?>
                                                    <?php $__env->startPush('scripts'); ?>

                                                        <script>
                                                        $(document).ready(function(){
                                                            $('#input-1').rating({
                                                                language: 'es',
                                                                step: 1,
                                                                theme: 'krajee-fa',
                                                                starCaptions: {1: 'Muy Malo', 2: 'Malo', 3: 'Está bien', 4: 'Bueno', 5: 'Muy Bueno'},
                                                                    starCaptionClasses: {1: 'text-danger', 2: 'text-warning', 3: 'text-info', 4: 'text-primary', 5: 'text-success'}
                                                            });
                                                        });
                                                        </script>
                                                    <?php $__env->stopPush(); ?>
                                                </div>
                                                <span><?php echo e($product->timesRated()); ?> (<?php echo e(round($product->userAverageRating, 1)); ?>)</span>
                                                <div class="customer-rev">
                                                    <a href="#" data-toggle="modal" data-target="#modal-default">Escribir un Comentario</a>
                                                </div>
                                                <div class="pro-review">
                                                    
                                                    <span>
                                                        <div class="availability mt-10">
                                                            <h5>Disponible:</h5>
                                                            <span><?php echo e($product->stock); ?> <br> en inventario</span>
                                                        </div>
                                                    </span>
                                                    <span>
                                                        <div class="pricebox">
                                                            <span class="regular-price">$<?php echo e($product->sell_price); ?></span>
                                                        </div>
                                                    </span>
                                                </div>
                                                <?php echo Form::open(['route'=>['shopping_cart_details.store', $product], 'method' => 'POST']); ?>

                                               
                                                    
                                                <div class="quantity-cart-box d-flex align-items-center ">
                                                    <div class="row">
                                                        <div class="col-12 py-2">
                                                            <div class="quantity">
                                                                <div class="pro-qty"><input type="text" name="quantity" value="1"></div>
                                                            </div>

                                                        </div>
                                                        <div class="col-12">

                                                            <div class="pro-size mb-20 mt-20">
                                                                <div class="row">
                                                                    <div class="col-12">
                                                                        <h5>Tamaño:</h5>
                                                                    </div>
                                                                    <div class="col-12">
                                                                        <select class="nice-select" name="size" >
                                                                            <?php $__currentLoopData = $product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <option value="<?php echo e($size->name); ?>"><?php echo e($size->name); ?></option>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                            
                                                                            
                                                                        </select>
                                                                    </div>
                                                                </div>
                                                                
                                                                
                                                            </div>
                                                        </div>
                                                        <div class="col-12 py-2">
                                                            <div class="action_link">
                                                                <button class="buy-btn" type="submit">add to cart
                                                                    <i class="fa fa-shopping-cart"></i>
                                                                </button>
                                                            </div>

                                                        </div>
                                                    </div>
                                                </div>
                                                <?php echo Form::close(); ?>

                                                    
                                                </div>
                                            </div>                          
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                                    
                                    
                                
                                
                               
                                
                                
                                <div class="useful-links mt-20">
                                    <a href="#" data-toggle="tooltip" data-placement="top" title="Compare"><i
                                            class="fa fa-refresh"></i>compare</a>
                                    <a href="#" data-toggle="tooltip" data-placement="top" title="Wishlist"><i
                                            class="fa fa-heart-o"></i>wishlist</a>
                                </div>
                                <div class="share-icon mt-20">
                                    <a class="facebook" href="#"><i class="fa fa-facebook"></i>like</a>
                                    <a class="twitter" href="#"><i class="fa fa-twitter"></i>tweet</a>
                                    <a class="pinterest" href="#"><i class="fa fa-pinterest"></i>save</a>
                                    <a class="google" href="#"><i class="fa fa-google-plus"></i>share</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- product details inner end -->

                <!-- product details reviews start -->
                
                <!-- product details reviews end -->

                <!-- related products area start -->
                <?php echo $__env->make('web._related_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <!-- related products area end -->
            </div>

            <!-- sidebar start -->
            <div class="col-lg-2">
                <div class="shop-sidebar-wrap fix mt-md-22 mt-sm-22">
                    <!-- category start -->
                    <?php echo $__env->make('web._category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- category end -->

                    <!-- featured category start -->
                    
                        <?php echo $__env->make('web._featured_category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <!-- featured category end -->

                    <!-- manufacturer start -->
                    
                    <!-- manufacturer end -->

                    <!-- product tag start -->
                    <?php echo $__env->make('web._product_tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- product tag end -->

                    <!-- sidebar banner start -->
                    
                    <!-- sidebar banner end -->
                </div>
            </div>
            <!-- sidebar end -->
        </div>
    </div>
</div>
<!-- product details wrapper end -->


<!-- brand area start -->

<!-- brand area end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/subcategory_details.blade.php ENDPATH**/ ?>