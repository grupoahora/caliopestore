<div class="sidebar-widget mb-22">

    <div class="section-title-2 d-flex justify-content-between mb-28">
        <h3>Destacados</h3>
        <div class="category-append"></div>
    </div> <!-- section title end -->
    <div class="category-carousel-active row" data-row="4">
        <?php $__currentLoopData = $web_feacturedproducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col">
            <div class="category-item">
                <div class="category-thumb">
                    <a href="<?php echo e(route('web.product_details', $product)); ?>">
                        <img src="<?php echo e($product->images->pluck('url')[0]); ?>" alt="">
                    </a>
                    
                </div>
                <div class="category-content">
                    <h4><a href="<?php echo e(route('web.product_details', $product)); ?>"><?php echo e($product->name); ?></a></h4>
                    <div class="price-box ">
                        <div class="regular-price ">
                            $<?php echo e($product->sell_price); ?>

                        </div>
                        <div class="old-price ">
                            <del>$<?php echo e($product->sell_price); ?></del>
                        </div>
                        
                        <div class="ratings">
                            <input id="input_rate_<?php echo e($product->id); ?>2" name="rate" value="<?php echo e($product->AverageRating); ?>" class="rating-loading">
                            
                            <?php $__env->startPush('scripts'); ?>
                                <script>
                                    $(document).ready(function(){
                                        $('#input_rate_<?php echo e($product->id); ?>2').rating({
                                            min: 0,
                                            max: 5,
                                            theme: 'krajee-fa', 
                                            displayOnly: true,
                                            step: 1, 
                                            language: 'es',
                                            size: 'xs', 
                                            stars: 5,
                                            showCaption: false,
                                        });
                                    });
                                </script>
                            <?php $__env->stopPush(); ?>
                        </div>
                        <div class="pro-review">
                                <span><?php echo e($product->timesRated()); ?> (<?php echo e(round($product->userAverageRating, 1)); ?>) Calificació(s)</span>
                            </div>
                    </div>
                </div>
            </div> <!-- end single item -->
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div> <!-- end single item column -->
</div>

<?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/_featured_category.blade.php ENDPATH**/ ?>