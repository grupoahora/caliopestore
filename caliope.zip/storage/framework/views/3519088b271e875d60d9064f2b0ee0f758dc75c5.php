<a class="jsgrid-button jsgrid-edit-button" href="<?php echo e(route('products.show', $id)); ?>" title="ver detalles" target="_blank">
    <i class="far fa-eye"></i>Ver Detalles
</a><?php /**PATH C:\xampp\htdocs\caliope\resources\views/admin/category/_actions.blade.php ENDPATH**/ ?>