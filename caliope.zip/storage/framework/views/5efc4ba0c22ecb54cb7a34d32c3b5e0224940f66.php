
<?php $__env->startSection('title','Categoría ' .$category->name ); ?>
<?php $__env->startSection('styles'); ?>
<style type="text/css">
    .unstyled-button {
        border: none;
        padding: 0;
        background: none;
    }

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('create'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Detalles de categoría <?php echo e($category->name); ?>

        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('subcategories.index')); ?>">Categorías</a></li>
                <li class="breadcrumb-item active" aria-current="page"><?php echo e($category->name); ?></li>
            </ol>
        </nav>
    </div>

    <div class="row">
        <div class="col-md-4 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h4 class="card-title">
                        <i class="<?php echo e($category->icon); ?>"></i>
                        <?php echo e($category->name); ?>

                    </h4>
                    <ul class="solid-bullet-list">
                        <li>
                            <h5>Description</h5>
                            <p class="text-muted"><?php echo e($category->description); ?></p>
                        </li>
                    </ul>
                    
                </div>
                <div class="card-footer text-muted">
                    <?php echo Form::open(['route'=>['categories.destroy',$category], 'method'=>'DELETE']); ?>

                        <a class="btn btn-info" href="<?php echo e(route('categories.edit', $category)); ?>">Editar</a>  
                        <button type="submit" class="btn btn-danger float-right">Eliminar</button>
                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
        <div class="col-md-8 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">SubCategorías</h4>
                        
                        <div class="btn-group">
                            <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                                <a href="<?php echo e(route('subcategories.create', compact('category'))); ?>" class="dropdown-item" >Agregar</a>
                                

                            </div>
                        </div>
                    </div>

                    <div class="table-responsive">
                        <table id="order-listing" class="table">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Descripción</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($subcategory->id); ?></th>
                                    <td>
                                        <a href="#" class="get_products"
                                            data-artid="<?php echo e($subcategory->id); ?>"><?php echo e($subcategory->name); ?></a>
                                    </td>
                                    <td><?php echo e($subcategory->description); ?></td>
                                    <td style="width: 50px;">
                                        <?php echo Form::open(['route'=>['subcategories.destroy',$subcategory],
                                        'method'=>'DELETE']); ?>


                                        <a class="jsgrid-button jsgrid-edit-button"
                                            href="<?php echo e(route('subcategories.edit', $subcategory)); ?>" title="Editar">
                                            <i class="far fa-edit"></i>
                                        </a>

                                        <button class="jsgrid-button jsgrid-delete-button unstyled-button" type="submit"
                                            title="Eliminar">
                                            <i class="far fa-trash-alt"></i>
                                        </button>


                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Productos</h4>
                        
                    </div>

                    <div class="table-responsive">
                        <table id="products_listing" class="table">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Nombre</th>
                                    <th>Stock</th>
                                    <th>Precio</th>
                                    <th>Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($product->id); ?></th>
                            <td>
                                <a href="<?php echo e(route('products.show',$product)); ?>"><?php echo e($product->name); ?></a>
                            </td>
                            <td><?php echo e($product->stock); ?></td>
                            <td><?php echo e($product->sell_price); ?></td>


                            <td><?php echo e($product->category->name); ?></td>
                            <td style="width: 50px;">
                                <?php echo Form::open(['route'=>['products.destroy',$product], 'method'=>'DELETE']); ?>


                                <a class="jsgrid-button jsgrid-edit-button" href="<?php echo e(route('products.edit', $product)); ?>"
                                    title="Editar">
                                    <i class="far fa-edit"></i>
                                </a>

                                <button class="jsgrid-button jsgrid-delete-button unstyled-button" type="submit"
                                    title="Eliminar">
                                    <i class="far fa-trash-alt"></i>
                                </button>

                                <?php echo Form::close(); ?>

                            </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Registrar Subcategoria</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <?php echo Form::open(['route'=>'subcategories.store', 'method'=>'POST']); ?>

                <input type="hidden" name="category_id" value="<?php echo e($category->id); ?>">
                <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger">
                    <?php echo e($message); ?>

                </small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                <div class="form-group">
                    <label for="name">Nombre</label>
                    <input type="text" name="name" id="name" class="form-control" placeholder="Nombre" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger">
                        <?php echo e($message); ?>

                    </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-group">
                    <label for="description">Descripción</label>
                    <textarea class="form-control" name="description" id="description" rows="3" required></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <small class="text-danger">
                        <?php echo e($message); ?>

                    </small>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="submit" class="btn btn-success">Registrar</button>
                <button type="button" class="btn btn-light" data-dismiss="modal">Cancelar</button>
            </div>
            <?php echo Form::close(); ?>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('melody/js/profile-demo.js'); ?>

<?php echo Html::script('melody/js/data-table.js'); ?>

<?php if($errors->any()): ?>
<script>
    $(document).ready(function () {
        $("#exampleModal").modal("show");

    });

</script>
<?php endif; ?>
<script>
    $(function () {
        $('.get_products').click(function () {
            var elem = $(this);
            $.ajax({
                type: "GET",
                url: "/get_products_by_subcategory",
                data: "subcategory_id=" + elem.attr('data-artid'),
                dataType: "json",
                success: function (data1) {
                    console.log(data1);
                    /* Destruccion de tabla para ser recreada */
                    $('#products_listing').dataTable().fnDestroy(),
                        /* Creacion de tabla */
                        $('#products_listing').dataTable({
                            data: data1.data,
                            columns: [{
                                    "data": "id"
                                },
                                {
                                    "data": "name"
                                },
                                {
                                    "data": "sell_price"
                                },
                                {
                                    "data": "stock"
                                },
                                {
                                    "data": "btn"
                                }
                            ],
                        });
                }
            });
            return false;
        });
    });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/admin/category/show.blade.php ENDPATH**/ ?>