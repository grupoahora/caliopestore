
<div class="sidebar-widget mb-22">
    <div class="section-title-2 d-flex justify-content-between mb-28">
        <h4 >Mas texturas</h4>
        <div class="category-append"></div>
    </div> <!-- section title end -->
    <div class="category-carousel-active row" data-row="4">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-lg-12 mb-3 col-sm-12 col-6">
                <div class="img-container img-full fix mb-md-30 mb-sm-30">
                    
                        <a href="<?php echo e(route('web.product_details', $product)); ?>"><?php $__currentLoopData = $product->textures; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><img height="80px" width="auto" src="<?php echo e($image->url); ?>" 
                        class="<?php if($loop->first): ?>  <?php else: ?> d-none <?php endif; ?>" alt="<?php echo e($product->name); ?>">
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </a>
                        
                        
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/_category.blade.php ENDPATH**/ ?>