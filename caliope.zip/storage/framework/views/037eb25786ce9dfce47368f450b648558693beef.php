<div class="shop-sidebar-wrap mt-md-28 mt-sm-28">
    <!-- sidebar categorie start -->
    <div class="sidebar-widget mb-30">
        <div class="sidebar-title mb-10">
            <h3>Sub-Categorias</h3>
        </div>
        <div class="product-tag">
            <ul>
                
                <?php if(isset($subcategories)): ?>
                    <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class=" d-inline-block mr-1 pb-1">
                        <form class="" action="<?php echo e(route('web.search_products_by_subcategory')); ?>" method="GET" >
                            <div class="">
                                <input name="search_id_category" type="hidden" class="" value="<?php echo e($subcategory->category_id); ?>">
                                <input name="search_id_subcategory" type="hidden" class="" value="<?php echo e($subcategory->id); ?>">
                                <div class="d-block d-inline-block ">
                                    <button type="submit" class="w-auto my-1 shadowcaliope " ><?php echo e($subcategory->name); ?></button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <?php if(isset($web_subcategories)): ?>
                        <?php $__currentLoopData = $web_subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class=" d-inline-block mr-1 pb-1">
                            <form class="" action="<?php echo e(route('web.search_products_by_subcategory')); ?>" method="GET" >
                                <div class="">
                                    <input name="search_id_category" type="hidden" class="" value="<?php echo e($subcategory->category_id); ?>">
                                    <input name="search_id_subcategory" type="hidden" class="" value="<?php echo e($subcategory->id); ?>">
                                    <div class="d-block d-inline-block ">
                                        <button type="submit" class="w-auto my-1 shadowcaliope " ><?php echo e($subcategory->name); ?></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                <?php endif; ?>
                
            </ul>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/_subcategory.blade.php ENDPATH**/ ?>