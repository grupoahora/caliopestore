
<?php $__env->startSection('title','Detalles de pedido'); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('create'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Detalles de pedido
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('orders.index')); ?>">Pedidos</a></li>
                <li class="breadcrumb-item active" aria-current="page">Detalles de pedido</li>
            </ol>
        </nav>
    </div>


    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-body">
                    <div class="row invoice-info">
                        <div class="col-sm-4 invoice-col">
                            De
                            <address>
                                <strong><?php echo e($business->name); ?></strong><br>
                                <?php echo e($business->address); ?><br>
                                Teléfono: <?php echo e($business->phone); ?><br>
                                Email: <?php echo e($business->email); ?>

                            </address>
                        </div>
                        <!-- /.col -->
                        <div class="col-sm-4 invoice-col">
                            A
                            <address>
                                <strong><?php echo e($order->user->name); ?> <?php echo e($order->user->profile->last_name); ?></strong><br>
                                <?php echo e($order->user->profile->address); ?><br>
                                Teléfono: <?php echo e($order->user->profile->phone); ?><br>
                                Email: <?php echo e($order->user->profile->email); ?>

                            </address>
                        </div>
                        <div class="col-sm-4 invoice-col">
                            
                            <br>
                            <b>Order ID:</b> <?php echo e($order->code); ?><br>
                            <b>Payment Due:</b><?php echo e($order->payment_status); ?><br>
                            <b>Fecha de pedido:</b> <?php echo e($order->order_date); ?>

                        </div>
                        <!-- /.col -->
                    </div>
                    
            <div class="form-group">
                <h4 class="card-title">Detalles de pedido</h4>
                <div class="table-responsive col-md-12">
                    <table id="details" class="table">
                        <thead>
                            <tr>
                                <th>Producto</th>
                                <th>Precio Venta (PEN)</th>
                                <th>Cantidad</th>
                                <th>SubTotal(PEN)</th>
                            </tr>
                        </thead>
                        <tfoot>

                            <tr>
                                <th colspan="4">
                                    <p align="right">SUBTOTAL:</p>
                                </th>
                                <th>
                                    <p align="right">$<?php echo e($order->subtotal()); ?></p>
                                </th>
                            </tr>

                            
                            <tr>
                                <th colspan="4">
                                    <p align="right">TOTAL:</p>
                                </th>
                                <th>
                                    <p align="right">$<?php echo e(number_format($order->subtotal(),2)); ?></p>
                                </th>
                            </tr>

                        </tfoot>
                        <tbody>
                            <?php $__currentLoopData = $order->order_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($detail->product->name); ?></td>
                                <td>s/ <?php echo e($detail->price); ?></td>
                                <td><?php echo e($detail->quantity); ?></td>
                                <td>s/<?php echo e(number_format($detail->total(),2)); ?>

                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <div class="card-footer text-muted">
            <a href="<?php echo e(route('orders.index')); ?>" class="btn btn-primary float-right">Regresar</a>
        </div>
    </div>
</div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('melody/js/profile-demo.js'); ?>

<?php echo Html::script('melody/js/data-table.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/admin/order/show.blade.php ENDPATH**/ ?>