
<div class="header-middle-searchbox">

    <form action="" >
        <div class="input-group">
            <input id="search_products" type="text" class="form-control" placeholder="Buscando...">
            <div class="input-group-append">
                <button type="button" class="search-btn"><i class="fa fa-search"></i></button>
            </div>
        </div>
    </form>
</div>
    <?php $__env->startPush('scripts'); ?>
    
    

    <?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/layouts/_search_products.blade.php ENDPATH**/ ?>