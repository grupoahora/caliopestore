
<?php $__env->startSection('meta_description', ''); ?>
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- breadcrumb area start -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('web.welcome')); ?>">Inicio</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Contactanos</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb area end -->

<!-- contact area start -->
<div class="contact-area pb-34 pb-md-18 pb-sm-0">
    <div class="container">
        <div class="row">
            <div class="col-lg-6">
                <div class="contact-message">
                    <h2>Caliope</h2>
                    
                    <form  action="<?php echo e(route('contact.mail.store')); ?>"
                        method="post" class="contact-form">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <input name="contact_first_name" placeholder="Nombre Completo *" type="text" required>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <input name="contact_phone" placeholder="Teléfono *" type="text" required>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <input name="contact_email_address" placeholder="Correo Electrónico*" type="text" required>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6">
                                <input name="contact_subject" placeholder="Asunto *" type="text">
                            </div>
                            <div class="col-12">
                                <div class="contact2-textarea text-center">
                                    <textarea placeholder="Message *" name="contact_mensaje" class="form-control2"
                                        required=""></textarea>
                                </div>
                                <div class="contact-btn">
                                    <button class="sqr-btn" type="submit">Enviar Mensaje</button>
                                </div>
                            </div>
                            <div class="col-12 d-flex justify-content-center">
                                <p class="form-messege"></p>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-lg-6">
                <div class="contact-info mt-md-28 mt-sm-28">
                    <h2>Contactanos</h2>
                    <p><?php echo e($web_company->contact_text); ?></p>
                    <ul>
                        <li><i class="fa fa-fax"></i> Dirección : <?php echo e($web_company->address); ?></li>
                        <li><i class="fa fa-phone"></i> <?php echo e($web_company->mail); ?></li>
                        <li><i class="fa fa-envelope-o"></i> + 57<?php echo e($web_company->phone); ?></li>
                    </ul>
                    <div class="working-time">
                        <h3>Horario de Trabajo</h3>
                        <p><?php echo e($web_company->hours_of_operation); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- contact area end -->

<!-- map area start -->
<div class="map-area-wrapper">
    <div class="container">
        <div id="map_content" data-lat="<?php echo e($web_company->latitude); ?>" data-lng="<?php echo e($web_company->length); ?>" data-zoom="55" data-maptitle="<?php echo e($web_company->name); ?>"
            data-mapaddress="<?php echo e($web_company->address); ?>">
        </div>
    </div>
</div>
<!-- map area end -->

<!-- brand area start -->

<!-- brand area end -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/contact_us.blade.php ENDPATH**/ ?>