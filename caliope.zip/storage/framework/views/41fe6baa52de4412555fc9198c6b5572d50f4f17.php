
<?php $__env->startSection('meta_description', ''); ?>
<?php $__env->startSection('title', 'Caliope'); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- breadcrumb area start -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('web.welcome')); ?>">Inicio</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('web.shop_grid')); ?>">Productos</a></li>
                            <li class="breadcrumb-item active" aria-current="page">checkout</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb area end -->

<!-- checkout main wrapper start -->
<div class="checkout-page-wrapper mt-3">
    <div class="container">
                <div class="row">
            <!-- Checkout Billing Details -->
            <div class="col-lg-6">
                <div class="checkout-billing-details-wrap">
                    <h2>Detalles de Facturación</h2>
                    <div class="billing-form-wrap">
                      <!-- Order Summary Table -->
                        <div class="order-summary-table table-responsive text-center">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th class="h4">Productos</th>
                                        <th class="h4">Total</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <a href="<?php echo e(route('web.product_details', $product->product)); ?>">
                                                    <?php echo e($product->product->name); ?> 
                                                    <strong>
                                                         × <?php echo e($product->quantity); ?> 
                                                    </strong>
                                                </a>
                                            </td>
                                            <td>
                                                $<?php echo e($product->total()); ?> 
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td>Sub Total</td>
                                        
                                        <td><strong>$<?php echo e($subtotal); ?></strong></td>
                                    </tr>
                                    <tr>
                                        <td>Envío</td>
                                        <td class="d-flex justify-content-center">
                                            
                                            <ul class="shipping-type">
                                                <li>
                                                    
                                                    <strong>
                                                        <div class="fw-700">Envío Gratis</div>
                                                    </strong>
                                                        
                                                        <div class="form-label">
                                                            El tiempo de envìo esta sujeto <br> a la empresa Domiciliaria
                                                        </div>
                                                        
                                                        
                                                    </li>
                                                </ul>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>Total</td>
                                        <td><strong>$<?php echo e($shopping_cart->total_price()); ?></strong></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Order Summary Details -->
            <div class="col-lg-6">
                <div class="order-summary-details mt-md-26 mt-sm-26">
                    <h2>Metodo de Pago</h2>
                    <div class="order-summary-content mb-sm-4">
                        
                        <!-- Order Payment Method -->
                        <form action="<?php echo e(route('pay')); ?>" method="post">
                            <?php echo csrf_field(); ?>
                            <div class="order-payment-method">



                                <?php $__currentLoopData = $paymentPlatforms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $paymentPlatform): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="single-payment-method show">
                                    <div class="payment-method-name
                                        <?php if($loop->first): ?>
                                            show
                                        <?php endif; ?>">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="<?php echo e($key); ?>" name="paymentmethod" value="<?php echo e($paymentPlatform->id); ?>"
                                                class="custom-control-input" 
                                                
                                                <?php if($loop->first): ?>
                                                    checked
                                                <?php endif; ?>
                                                
                                                required />
                                            <label class="custom-control-label" for="<?php echo e($key); ?>"><?php echo e($paymentPlatform->name); ?>

                                            <img src="<?php echo e($paymentPlatform->image); ?>" class="img-fluid paypal-card"
                                            alt="<?php echo e($paymentPlatform->name); ?>" /></label>
                                        </div>
                                    </div>
                                    <div class="payment-method-details" data-method="<?php echo e($paymentPlatform->id); ?>">
                                        <?php if ($__env->exists('components.' . strtoupper($paymentPlatform->name) . '-collapse')) echo $__env->make('components.' . strtoupper($paymentPlatform->name) . '-collapse', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                                
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                <div class="summary-footer-area">
                                    <div class="custom-control custom-checkbox mb-14">
                                        <input type="checkbox" class="custom-control-input" id="terms" required />
                                        <label class="custom-control-label" for="terms">He leido y accepto Terminos y condiciones de <a href="<?php echo e(route('web.welcome')); ?>">Caliope.com.com.</a></label>
                                    </div>
                                    <button type="submit" class="check-btn sqr-btn">Pagar</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- checkout main wrapper end -->



<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>



<script src="galio/assets/js/switcher.js"></script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/checkout.blade.php ENDPATH**/ ?>