
<?php $__env->startSection('title','Registrar producto'); ?>
<?php $__env->startSection('styles'); ?>
<?php echo Html::style('select2/dist/css/select2.min.css'); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Registro de productos
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('products.index')); ?>">Productos</a></li>
                <li class="breadcrumb-item active" aria-current="page">Registro de productos</li>
            </ol>
        </nav>
    </div>
    <?php echo Form::open(['route'=>'products.store', 'method'=>'POST','files' => true]); ?>

    <div class="row">
        <div class="col-8 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="name">Nombre</label>
                        <input type="text" name="name" id="name" class="form-control" aria-describedby="helpId"
                            required>
                    </div>
                    <div class="form-row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="code">Código de barras</label>
                                <input type="text" name="code" id="code" class="form-control">
                                <small id="helpId" class="text-muted">Campo opcional</small>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="code">Stock</label>
                                <input type="text" name="stock" id="code" class="form-control">
                                <small id="helpId" class="text-muted">Campo opcional</small>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label for="sell_price">Precio de venta</label>
                                <input type="number" name="sell_price" id="sell_price" class="form-control"
                                    aria-describedby="helpId" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="short_description">Extracto</label>
                        <textarea class="form-control" name="short_description" id="short_description"
                            rows="3"></textarea>
                    </div>
                    <div class="form-group">
                        <label for="long_description">Descripción</label>
                        <textarea class="form-control" name="long_description" id="long_description"
                            rows="10"></textarea>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-4 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <label for="category_id">Categoría</label>
                        <select class="select2" name="category_id" id="category" style="width: 100%">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($category->id); ?>" ><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['category_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger">
                                <?php echo e($message); ?>

                            </small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                    </div>
                    <div class="form-group">
                        <label for="subcategory_id">Subcategoría</label>
                        <select class="select2" name="subcategory_id" id="subcategory_id" style="width: 100%">
                            <option value="" disabled selected>-- Selecciona una Categoria --</option>
                            
                        </select>
                        <?php $__errorArgs = ['subcategory_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger">
                                <?php echo e($message); ?>

                            </small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    
                    <div class="form-group">
                        <label for="tags">Etiquetas</label>
                        <select class="select2" name="tags[]" id="tags" style="width: 100%" multiple>
                            <?php $__currentLoopData = $tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($tag->id); ?>"><?php echo e($tag->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="colors">Colores</label>
                        <select class="select2" name="colors[]" id="colors" style="width: 100%" multiple>
                            <?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($color->id); ?>">
                                <?php echo e($color->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="sizes">Tamaños</label>
                        <select class="select2" name="sizes[]" id="sizes" style="width: 100%" multiple>
                            <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($size->id); ?>">
                                <?php echo e($size->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-12 grid-margin">
            <div class="card">
                
                <div class="card-body">
                    <h4 class="card-title">Imagenes de producto</h4>
                    <input type="file" name="images[]" class="dropify" multiple />
                </div>
            </div>
        </div>
        
        
    </div>
    <button type="submit" class="btn btn-primary mr-2">Registrar</button>
    <a href="<?php echo e(route('products.index')); ?>" class="btn btn-light">
        Cancelar
    </a>
    <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('melody/js/data-table.js'); ?>

<?php echo Html::script('melody/js/dropify.js'); ?>


<?php echo Html::script('melody/js/dropzone.js'); ?>

<?php echo Html::script('ckeditor/ckeditor.js'); ?>

<script>
    CKEDITOR.replace('long_description');

</script>
<script>
    $(document).ready(function () {
        $('#category').select2();
        $('#subcategory_id').select2();
        $('#tags').select2();
        $('#colors').select2();
        $('#sizes').select2();
        $('#position').select2();
        $('#position2').select2();
        

    });

</script>
<script>
      var category = $('#category');
      var subcategory_id = $('#subcategory_id');
      category.change(function(){
          $.ajax({
              url: "<?php echo e(route('get_subcategories')); ?>",
              method: 'GET',
              data: {
                  category: category.val(),
              },
              success: function(data){
                  subcategory_id.empty();
                  subcategory_id.append('<option disabled selected>-- Selecciona una Subcategoria --</option>');
                  $.each(data, function(index, element){
                      subcategory_id.append('<option value="'+ element.id +'">'+ element.name +'</option>')
                  });
              }
          });
      });
    
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/admin/product/create.blade.php ENDPATH**/ ?>