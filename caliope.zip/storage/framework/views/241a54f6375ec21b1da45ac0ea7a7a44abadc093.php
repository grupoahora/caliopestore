
<?php $__env->startSection('meta_description', ''); ?>
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- breadcrumb area start -->
<div class="breadcrumb-area">
    <div class="container-fluid">
        <div class="row mx-5">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('web.welcome')); ?>">Inicio</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('web.shop_grid')); ?>">Tienda</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Detalles de producto</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb area end -->

<!-- product details wrapper start -->
<div class="product-details-wrapper">
    <div class="container-fluid">
        <div class="row mx-2 mx-sm-5">
            <div class="col-lg-9 ml-auto">
                <!-- product details inner end -->
                <div class="product-details-inner">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="product-large-slider mb-20 slick-arrow-style_2" autoplay>
                                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="pro-large-img img-zoom" id="img<?php echo e($image->id); ?>">
                                        <img src="<?php echo e($image->url); ?>" alt="<?php echo e($product->name); ?>" />
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="rol p-0 m-0">
                                <div class="col-12 m-0 p-0 h-300-md">

                                    <div class="pro-nav  slick-padding2 slick-arrow-style_2" autoplay>
                                        <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <div class="pro-nav-thumb  "><img class="h-300-md" src="<?php echo e($image->url); ?>"
                                                alt="<?php echo e($product->name); ?>" /></div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </div>
                                </div>
                            </div>
                            
                            
                        </div>
                        <div class="col-lg-5">
                            <div class="product-details-des mt-md-34 mt-sm-34">
                                <h3><a href="<?php echo e(route('web.product_details', $product)); ?>"><?php echo e($product->name); ?></a></h3>
                                <?php echo $__env->make('web.products._ratings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                <div class="customer-rev">
                                    <a href="#" data-toggle="modal" data-target="#modal-default">Escribir un Comentario</a>
                                </div>
                                <div class="availability mt-10">
                                    <h5>Disponible:</h5>
                                    <span><?php echo e($product->stock); ?> en inventario</span>
                                </div>
                                <div class="pricebox">
                                    <span class="regular-price">$<?php echo e($product->sell_price); ?></span>
                                </div>
                                <p><?php echo e($product->short_description); ?></p>
                                
                                
                                <?php echo $__env->make('web._add_to_shopping_cart_form', ['class'=>''], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                
                                <div class="share-icon mt-20">
                                    <?php $__currentLoopData = $web_socialmedias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $socialmedia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="<?php echo e($socialmedia->name); ?>" href="<?php echo e($socialmedia->url); ?>" title="<?php echo e($socialmedia->name); ?>"><i class="fa <?php echo e($socialmedia->icon); ?>"></i></a>
                                
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- product details inner end -->

                <!-- product details reviews start -->
                
                <!-- product details reviews end -->

                <!-- related products area start -->
                <!-- related products area end -->
                
            </div>

            <!-- sidebar start -->
            <div class="col-lg-2 mr-auto ">
                <div class="shop-sidebar-wrap fix mt-md-22 mt-sm-22">
                    <!-- category start -->
                    <?php echo $__env->make('web._category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- category end -->

                    <!-- featured category start -->
                    
                        <?php echo $__env->make('web._featured_category', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    
                    <!-- featured category end -->

                    <!-- manufacturer start -->
                    
                    <!-- manufacturer end -->

                    <!-- product tag start -->
                    <?php echo $__env->make('web._product_tag', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <!-- product tag end -->

                    <!-- sidebar banner start -->
                    
                    <!-- sidebar banner end -->
                </div>
            </div>
            <div class="col-lg-11 mx-auto col">
                <div class="product-details-reviews mt-34">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="product-review-info">
                                <ul class="nav review-tab">
                                    <li>
                                        <a class="active" data-toggle="tab" href="#tab_one">Descripción</a>
                                    </li>
                                    
                                    <li>
                                        <a data-toggle="tab" href="#tab_three">Comentarios</a>
                                    </li>
                                </ul>
                                <div class="tab-content reviews-tab">
                                    <div class="tab-pane fade show active" id="tab_one">
                                        <div class="tab-one">
                                            <?php echo $product->long_description; ?>

                                        </div>
                                    </div>
                                    
                                    <div class="tab-pane fade" id="tab_three">
                                        <?php echo $__env->make('web.products.review_product_form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-11 mx-auto col">
                <?php echo $__env->make('web._related_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
            
            <!-- sidebar end -->
        </div>
    </div>
</div>
<!-- product details wrapper end -->


<!-- brand area start -->

<!-- brand area end -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

 


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/product_details.blade.php ENDPATH**/ ?>