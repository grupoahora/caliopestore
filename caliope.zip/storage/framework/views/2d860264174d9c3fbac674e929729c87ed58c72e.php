
<?php $__env->startSection('meta_description', ''); ?>
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- breadcrumb area start -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('web.welcome')); ?>">Inicio</a></li>
                            <li class="breadcrumb-item"><a href="<?php echo e(route('web.shop_grid')); ?>">Tienda</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Mi Carrito</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb area end -->

<!-- cart main wrapper start -->
<div class="cart-main-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <?php echo Form::open(['route'=> 'shopping_cart.update', 'method'=>'PUT']); ?>

                <!-- Cart Table Area -->
                <div class="cart-table table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th class="pro-thumbnail">Miniatura</th>
                                <th class="pro-title">Producto</th>
                                <th class="pro-title">tamaño</th>
                                <th class="pro-price">Precio</th>
                                <th class="pro-quantity">Cantidad</th>
                                <th class="pro-subtotal">Total</th>
                                <th class="pro-remove">Eliminar</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $shopping_cart->shopping_cart_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shopping_cart_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="pro-thumbnail"><a href="<?php echo e(route('web.product_details', $shopping_cart_detail->product)); ?>"><img class="img-fluid"
                                                src="<?php echo e($shopping_cart_detail->product->images->pluck('url')[0]); ?>" alt="<?php echo e($shopping_cart_detail->product->name); ?>" /></a></td>
                                    <td class="pro-title"><a href="<?php echo e(route('web.product_details', $shopping_cart_detail->product)); ?>"><?php echo e($shopping_cart_detail->product->name); ?></a></td>
                                    <td class="pro-title">
                                    <?php echo e($shopping_cart_detail->size); ?>

                                    </td>
                                    <td class="pro-price"><span>$<?php echo e($shopping_cart_detail->product->sell_price); ?></span></td>
                                    <td class="pro-quantity">
                                        <div class="pro-qty"><input type="text" name="quantity[]" value="<?php echo e($shopping_cart_detail->quantity); ?>"></div>
                                    </td>
                                    <td class="pro-subtotal"><span>$<?php echo e($shopping_cart_detail->total()); ?></span></td>
                                    <td class="pro-remove"><a method="" href="<?php echo e(route('shopping_cart_details.destroy', $shopping_cart_detail)); ?>"><i class="fa fa-trash-o"></i></a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                        </tbody>
                    </table>
                </div>

                <!-- Cart Update Option -->
                <div class="cart-update-option d-block d-md-flex justify-content-between">
                    
                    <div class="cart-update mt-sm-16">
                        <button type="submit" href="#" class="sqr-btn">Actualizar Carrito</button>
                        
                    </div>
                </div>
                <?php echo Form::close(); ?>

            </div>
        </div>

        <div class="row mb-5">
            <div class="col-lg-5 ml-auto">
                <!-- Cart Calculation Area -->
                <div class="cart-calculator-wrapper">
                    <div class="cart-calculate-items">
                        <h3>Total</h3>
                        <div class="table-responsive">
                            <table class="table">
                                <tr>
                                    <td>Sub Total</td>
                                    <td>$<?php echo e($shopping_cart->total_price()); ?></td>
                                </tr>
                                <tr>
                                    <td>Domicilio</td>
                                    <td>$0.00</td>
                                </tr>
                                <tr class="total">
                                    <td>Total</td>
                                    <td class="total-amount">$<?php echo e($shopping_cart->total_price()); ?></td>
                                </tr>
                            </table>
                        </div>
                    </div>
                    <a href="<?php echo e(route('web.checkout')); ?>" class="sqr-btn d-block">Continuar Con El Pago</a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- cart main wrapper end -->

<!-- brand area start -->

<!-- brand area end -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/cart.blade.php ENDPATH**/ ?>