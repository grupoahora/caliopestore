<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <h1>
        Mensaje de <?php echo e(config('app.name', 'Tienda en linea')); ?>

    </h1>
    <p><strong>Nombre Completo: <?php echo e($contact_first_name); ?></strong></p><br>
    <p><strong>Teléfono: <?php echo e($contact_phone); ?></strong></p><br>
    <p><strong>Correo Electrónico: <?php echo e($contact_email_address); ?></strong></p><br>
    <p><strong>Asunto: <?php echo e($contact_subject); ?></strong></p><br>
    <p><strong>Mensaje: <?php echo e($contact_mensaje); ?></strong></p><br>
</body>
</html><?php /**PATH C:\xampp\htdocs\caliope\resources\views/emails/contact.blade.php ENDPATH**/ ?>