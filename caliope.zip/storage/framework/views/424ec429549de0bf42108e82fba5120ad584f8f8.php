
<?php $__env->startSection('content_tab'); ?>
<div class="col-lg- col-md-8">
    

    

    <!-- Single Tab Content Start -->
    
    <!-- Single Tab Content End -->

    <!-- Single Tab Content Start -->
    <div class="myaccount-content">
        <h3>Cambio de Contraseña</h3>
        <div class="account-details-form">
            <?php echo Form::model($user,['route'=>['web.update_password', $user], 'method'=>'PUT']); ?>

                
                <div class="single-input-item">
                    <label for="old_password" class="required">Contraseña Actual</label>
                    <input type="password" id="old_password" 
                        name="old_password" placeholder="Contraseña Actual" required />
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="single-input-item">
                            <label for="password" class="required">Nueva Contraseña</label>
                            <input type="password" id="password" 
                                name="password" placeholder="Nueva Contraseña" required/>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="single-input-item">
                            <label for="password-confirm" class="required">Confirmar Contraseña</label>
                            <input type="password" id="password-confirm" 
                                name="password_confirmation" placeholder="Confirmar Contraseña" />
                        </div>
                    </div>
                </div>
                <div class="single-input-item">
                    <button class="check-btn sqr-btn ">Guardar Cambios</button>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>

    
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.my_account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/change_password.blade.php ENDPATH**/ ?>