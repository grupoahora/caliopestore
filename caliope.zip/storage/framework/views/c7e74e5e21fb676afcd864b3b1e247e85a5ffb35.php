<div class="ratings">
    <input id="input_rate_<?php echo e($product->id); ?>" name="rate" value="<?php echo e($product->AverageRating); ?>" class="rating-loading">
    <?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function(){
            $('#input_rate_<?php echo e($product->id); ?>').rating({
                min: 0,
                max: 5,
                theme: 'krajee-fa', 
                displayOnly: true,
                step: 1, 
                language: 'es',
                size: 'xs', 
                stars: 5,
                showCaption: false,
            });
        });
    </script>
    <?php $__env->stopPush(); ?>
</div>
<div class="pro-review">
    <span><?php echo e($product->timesRated()); ?> (<?php echo e(round($product->userAverageRating, 1)); ?>) Calificació(s)</span>
</div>
<?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/products/_ratings.blade.php ENDPATH**/ ?>