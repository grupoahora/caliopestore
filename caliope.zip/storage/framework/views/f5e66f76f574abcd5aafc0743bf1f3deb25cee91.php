
<?php $__env->startSection('content_tab'); ?>
<div class="col-lg- col-md-8">
    
    <div class="myaccount-content">
        <h3>Dirección de Envío</h3>
        <address>
            <p><strong><?php echo e($user->name); ?> <?php echo e($user->surname); ?></strong></p>
            <p><?php echo e($profile->address); ?> <br>
                </p>
            <p>Teléfono: <?php echo e($profile->phone); ?></p>
        </address>
        <a href="#" class="check-btn sqr-btn " data-toggle="modal" data-target="#modal-default"><i
                class="fa fa-edit"></i> Editar Dirección</a>
    </div>
    <div class="modal fade" id="modal-default">
        <div class="modal-dialog">
            <div class="modal-content rounded-0">
                <div class="modal-header">
                    <h4 class=" h5 modal-title  mx-auto pt-3">Editar Dirección</h4>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <?php echo Form::model($profile,['route'=>['update_profile', $profile], 'method'=>'PUT']); ?>

                <div class="modal-body">
                    <div class="single-input-item">
                        <label for="address" class="required">Dirección de envío</label>
                        <input type="text" id="address" 
                        name="address" 
                        value="<?php echo e(old('address', $profile->address )); ?>" 
                        placeholder="Dirección de envío" />
                    </div>
                    <div class="single-input-item">
                        <label for="phone" class="required">Número de teléfono/celular</label>
                        <input type="number" id="phone" 
                        name="phone"
                        value="<?php echo e(old('phone', $profile->phone )); ?>"
                        placeholder="Número de teléfono/celular" />
                    </div>
                </div>
                <div class="modal-footer justify-content-between">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                    <button type="submit" class="check-btn sqr-btn">Guardar cambios</button>
                </div>
                <?php echo Form::close(); ?>

            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.my_account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/address_edit.blade.php ENDPATH**/ ?>