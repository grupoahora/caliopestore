
<?php $__env->startSection('title','Editar categoría'); ?>
<?php $__env->startSection('styles'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>


<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Editar subcategoría
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('categories.index')); ?>">Categorías</a></li>
                <li class="breadcrumb-item"><a href="<?php echo e(route('categories.show', $subcategory->category_id)); ?>">Volver</a></li>
                <li class="breadcrumb-item active" aria-current="page">Editar subcategoría</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-lg-8 grid-margin stretch-card">
            <div class="card">
                <?php if(session('info')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('info')); ?>

                    </div>
                <?php endif; ?>
                <div class="card-body">
                    
                    
                    <?php echo Form::model($subcategory,['route'=>['subcategories.update',$subcategory], 'method'=>'PUT']); ?>

                    
                    
                    <div class="form-group">
                        <label for="name">Nombre</label>
                        <input type="text" name="name" id="name" value="<?php echo e($subcategory->name); ?>" class="form-control" placeholder="Nombre" required>
                      </div>
                      <div class="form-group">
                        <label for="description">Descripción</label>
                        <textarea class="form-control" name="description" id="description" rows="3"><?php echo e($subcategory->description); ?></textarea>
                    </div>
                    

                     <button type="submit" class="btn btn-primary mr-2">Actualizar</button>
                     <a href="<?php echo e(URL::previous()); ?>" class="btn btn-light">
                        Cancelar
                     </a>
                     <?php echo Form::close(); ?>

                </div>
                
            </div>
        </div>
        <div class="col-lg-4 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="form-group">
                        <h4 class="card-title">Actualizar Textura</h4>
                        <div class="file-upload-wrapper">
                            <div id="fileuploader" >Subir</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <?php echo csrf_field(); ?>
                    <h4 class="card-title">Galeria de Texturas</h4>
                    <div id="lightgallery" class="row lightGallery">
                        <?php $__currentLoopData = $subcategory->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <a href="<?php echo e($image->url); ?>" class="image-tile"><img
                                src="<?php echo e($image->url); ?>" alt="image small"></a>
                        
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('melody/js/data-table.js'); ?>

<?php echo Html::script('melody/vendors/lightgallery/js/lightgallery-all.min.js'); ?>

<?php echo Html::script('melody/js/light-gallery.js'); ?>

<script>
      
        (function($) {
            'use strict';
            if ($("#fileuploader").length) {
                $("#fileuploader").uploadFile({
                url: "/upload/subcategory/<?php echo e($subcategory->id); ?>/image",
                fileName: "image",
                
                });
            }
            
        })(jQuery);
        
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/admin/subcategories/edit.blade.php ENDPATH**/ ?>