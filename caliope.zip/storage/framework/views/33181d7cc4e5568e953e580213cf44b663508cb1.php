
<?php $__env->startSection('content_tab'); ?>
<div class="col-lg- col-md-8">
    
        
        
            <div class="myaccount-content">
                <h3>Orders</h3>
                <div class="myaccount-table table-responsive text-center">
                    <table class="table table-bordered">
                        <thead class="thead-light">
                            <tr>
                                <th>Pedido</th>
                                <th>Fecha</th>
                                <th>Estado</th>
                                <th>Total</th>
                                <th>Acción</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($order->id); ?></td>
                                <td><?php echo e($order->order_date); ?></td>
                                <td><?php echo e($order->shipping_status); ?></td>
                                <td>$<?php echo e($order->subtotal()); ?></td>
                                <td><a href="<?php echo e(route('web.order_details', $order)); ?>" class="check-btn sqr-btn ">View</a></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan=5 >No tienes pedidos, haz <a href="<?php echo e(route('web.shop_grid')); ?>">click aca </a>  para ir a la tienda</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.my_account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/orders.blade.php ENDPATH**/ ?>