<div class="col-lg-3 col-md-4 col-sm-6">
    <!-- product single grid item start -->
    <div class="product-item fix mb-30">
        <div class="product-thumb">
            <a href="<?php echo e(route('web.subcategory_details', $subcategory)); ?>">
                <?php $__currentLoopData = $subcategory->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e($image->url); ?>" 
                class="<?php if($loop->first): ?> img-pri <?php else: ?> img-sec <?php endif; ?>" alt="<?php echo e($subcategory->name); ?>">
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
            </a>
            <div class="product-label">
                <span>hot</span>
            </div>
            <div class="product-action-link">
                
                <a href="#" data-toggle="tooltip" data-placement="left" title="Wishlist"><i
                        class="fa fa-heart-o"></i></a>
                <a href="#" data-toggle="tooltip" data-placement="left" title="Compare"><i
                        class="fa fa-refresh"></i></a>
                
            </div>
        </div>
        <div class="product-content">
            <h4><a href="<?php echo e(route('web.subcategory_details', $subcategory)); ?>"><?php echo e($subcategory->name); ?></a></h4>
            
        </div>
    </div>
    <!-- product single grid item end -->
    <!-- product single list item start -->
    <div class="product-list-item mb-30">
        <div class="product-thumb">
            <a href="<?php echo e(route('web.subcategory_details', $subcategory)); ?>">
                <?php $__currentLoopData = $subcategory->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e($image->url); ?>" 
                class="<?php if($loop->first): ?> img-pri <?php else: ?> img-sec <?php endif; ?>" alt="<?php echo e($subcategory->name); ?>">
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </a>
            <div class="product-label">
                <span>hot</span>
            </div>
        </div>
        <div class="product-list-content">
            <h3><a href="<?php echo e(route('web.subcategory_details', $subcategory)); ?>"><?php echo e($subcategory->name); ?></a></h3>
            
            <p>
                <?php echo e($subcategory->short_description); ?>

            </p>
            <div class="product-list-action-link">
                
                <a href="#" data-toggle="modal" data-target=""> <span data-toggle="tooltip"
                        data-placement="top" title="Quick view"><i class="fa fa-search"></i></span> </a>
                <a href="#" data-toggle="tooltip" data-placement="top" title="Wishlist"><i
                        class="fa fa-heart-o"></i></a>
                <a href="#" data-toggle="tooltip" data-placement="top" title="Compare"><i class="fa fa-refresh"></i></a>
            </div>
        </div>
    </div>
    <!-- product single list item start -->
</div> <!-- product single column end -->
<?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/_subcategory_item.blade.php ENDPATH**/ ?>