<div class="sidebar-widget mb-22">
    <div class="sidebar-title mb-10">
        <h3>Etiquetas</h3>
    </div>
    <div class="sidebar-widget-body">
        <div class="product-tag">
            <?php $__currentLoopData = $web_tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class=" d-inline-block mr-1 pb-1 ">
                <form class="" action="<?php echo e(route('web.search_products_by_tag')); ?>" method="GET">
                    <div class="">
                        <input name="search_id_tag" type="hidden" class="" value="<?php echo e($tag->id); ?>">
                        <button type="submit" class="w-auto my-1 bg-transparente"><?php echo e($tag->name); ?></button>
                    </div>
                </form>
            </div>
            
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/_product_tag.blade.php ENDPATH**/ ?>