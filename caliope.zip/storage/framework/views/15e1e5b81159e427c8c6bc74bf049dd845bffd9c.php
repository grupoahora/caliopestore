

    <div class="row">
        <div class="col">
            <h5>1 review for Simple product 12</h5>
        </div>
        <div class="col">
            <div class="buttons float-right">
                <button class="sqr-btn" data-toggle="modal" data-target="#modal-default">Escribir comentario</button>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $product->ratings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $rating): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        
    
    <div class="total-reviews">
        <div class="rev-avatar">
            <img src="<?php echo e($rating->user->avatar); ?>" alt="">
            
        </div>
        <div class="review-box">
            <div class="review-box">
                <div class="ratings">
                    <input id="input_rate_<?php echo e($key); ?>" name="rate" value="<?php echo e($rating->rating); ?>" class="rating-loading">
                    <?php $__env->startPush('scripts'); ?>
                    <script>
                        $(document).ready(function(){
                            $('#input_rate_<?php echo e($key); ?>').rating({
                                min: 0,
                                max: 5,
                                theme: 'krajee-fa', 
                                step: 1, 
                                language: 'es',
                                size: 'xs', 
                                stars: 5,
                                displayOnly: true,
                                starCaptions: {1: 'Muy Malo', 2: 'Malo', 3: 'Está bien', 4: 'Bueno', 5: 'Muy Bueno'},
                                starCaptionClasses: {1: 'bg-danger text-white rounded-caliope', 2: 'bg-warning text-white rounded-caliope', 3: 'bg-info text-white rounded-caliope', 4: 'bg-primary text-white rounded-caliope ', 5: 'bg-success text-white rounded-caliope'}
                            });
                        });
                    </script>
                    <?php $__env->stopPush(); ?>
                    
                </div>
                <div class="post-author">
                    <p><span><?php echo e($rating->user->name); ?> -</span> <?php echo e($rating->created_at); ?></p>
                    <p><?php echo e($rating->comment); ?></p>
                </div>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    
    <?php $__env->startPush('modal'); ?>
        <div class="modal fade" id="modal-default">
            <div class="modal-dialog">
                <div class="modal-content rounded-0">
                    <div class="modal-header">
                        <h4 class="modal-title my-3">Editar Dirección</h4>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">×</span>
                        </button>
                    </div>
                    <?php echo Form::open(['route'=>['web.rate_product', $product], 'method'=>'POST']); ?>

                    <div class="modal-body">
                        
                        <div class="single-input-item">
                            <label class="col-form-label">
                                <span class="text-danger">*</span> 
                                Calificación general
                            </label>
                            <div class="form-group">
                                
                                <input id="input-1" name="rate" value="" class="rating-loading">
                            </div>
        
                        </div>
                        <div class="single-input-item">
                            <label class="col-form-label"><span class="text-danger">*</span>Comentario</label>
                            <textarea class="form-control" name="comment" required></textarea>
                            
                        </div>
                        

                                

                    </div>
                    <div class="modal-footer justify-content-between">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
                        <button type="submit" class="check-btn sqr-btn">Guardar cambios</button>
                    </div>
                    <?php echo Form::close(); ?>

                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>
    <?php $__env->stopPush(); ?>

    
 <!-- end of review-form -->



<?php $__env->startPush('scripts'); ?>

    <script>
    $(document).ready(function(){
        $('#input-1').rating({
            language: 'es',
            step: 1,
            theme: 'krajee-fa',
            starCaptions: {1: 'Muy Malo', 2: 'Malo', 3: 'Está bien', 4: 'Bueno', 5: 'Muy Bueno'},
                starCaptionClasses: {1: 'text-danger', 2: 'text-warning', 3: 'text-info', 4: 'text-primary', 5: 'text-success'}
        });
    });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/products/review_product_form.blade.php ENDPATH**/ ?>