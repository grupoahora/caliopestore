<div class="col-lg-3 col-md-4 col-sm-6">
    <!-- product single grid item start -->
    <div class="product-item fix mb-30">
        <div class="product-thumb">
            <a href="<?php echo e(route('web.product_details', $product)); ?>">
                <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <img src="<?php echo e($image->url); ?>" 
                class="<?php if($loop->first): ?> img-pri <?php else: ?> img-sec <?php endif; ?>" alt="<?php echo e($product->name); ?>">
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </a>
            <div class="product-label">
                <span>hot</span>
            </div>
            <div class="product-action-link">
                
                <a href="#" data-toggle="tooltip" data-placement="left" title="Wishlist"><i
                        class="fa fa-heart-o"></i></a>
                <a href="#" data-toggle="tooltip" data-placement="left" title="Compare"><i
                        class="fa fa-refresh"></i></a>
                <a href="<?php echo e(route('store_a_product', $product)); ?>" data-toggle="tooltip" data-placement="left" title="Add to cart"><i
                        class="fa fa-shopping-cart"></i></a>
            </div>
        </div>
        <div class="product-content">
            <h4><a href="<?php echo e(route('web.product_details', $product)); ?>"><?php echo e($product->name); ?></a></h4>
            <div class="pricebox">
                <span class="regular-price">$<?php echo e($product->sell_price); ?></span>
                <?php echo $__env->make('web.products._ratings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
            </div>
        </div>
    </div>
    <!-- product single grid item end -->
</div>

<?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/_product_feactured.blade.php ENDPATH**/ ?>