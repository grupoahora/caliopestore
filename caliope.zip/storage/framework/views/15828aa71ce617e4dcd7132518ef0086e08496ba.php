
<?php $__env->startSection('title','Gestión de ventas'); ?>
<?php $__env->startSection('styles'); ?>
<style type="text/css">
    .unstyled-button {
        border: none;
        padding: 0;
        background: none;
      }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('create'); ?>
<li class="nav-item d-none d-lg-flex">
    <a class="nav-link" href="<?php echo e(route('sales.create')); ?>">
      <span class="btn btn-primary">+ Registrar venta</span>
    </a>
  </li>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('options'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('preference'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content-wrapper">
    <div class="page-header">
        <h3 class="page-title">
            Ventas
        </h3>
        <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Panel administrador</a></li>
                <li class="breadcrumb-item active" aria-current="page">Ventas</li>
            </ol>
        </nav>
    </div>
    <div class="row">
        <div class="col-lg-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    
                    <div class="d-flex justify-content-between">
                        <h4 class="card-title">Ventas</h4>
                        
                        <div class="btn-group">
                            <a data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-ellipsis-v"></i>
                            </a>
                            <div class="dropdown-menu dropdown-menu-right">
                              <a href="<?php echo e(route('sales.create')); ?>" class="dropdown-item">Registrar</a>
                              
                            </div>
                          </div>
                    </div>

                    <div class="table-responsive">
                        <table id="order-listing" class="table">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Fecha</th>
                                    <th>Total</th>
                                    <th>Estado</th>
                                    <th style="width:50px;">Acciones</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row">
                                        <a href="<?php echo e(route('sales.show', $sale)); ?>"><?php echo e($sale->id); ?></a>
                                    </th>
                                    <td>
                                        <?php echo e(\Carbon\Carbon::parse($sale->sale_date)->format('d M y h:i a')); ?>

                                    </td>
                                    <td><?php echo e($sale->total); ?></td>

                                    <?php if($sale->status == 'VALID'): ?>
                                    <td>
                                        <a class="jsgrid-button btn btn-success" href="<?php echo e(route('change.status.sales', $sale)); ?>" title="Editar">
                                            Activo <i class="fas fa-check"></i>
                                        </a>
                                    </td>
                                    <?php else: ?>
                                    <td>
                                        <a class="jsgrid-button btn btn-danger" href="<?php echo e(route('change.status.sales', $sale)); ?>" title="Editar">
                                            Cancelado <i class="fas fa-times"></i>
                                        </a>
                                    </td>
                                    <?php endif; ?>

                                    <td style="width: 50px;">

                                        <a href="<?php echo e(route('sales.pdf', $sale)); ?>" class="jsgrid-button jsgrid-edit-button"><i class="far fa-file-pdf"></i></a>
                                        <a href="<?php echo e(route('sales.print', $sale)); ?>" class="jsgrid-button jsgrid-edit-button"><i class="fas fa-print"></i></a>
                                        <a href="<?php echo e(route('sales.show', $sale)); ?>" class="jsgrid-button jsgrid-edit-button"><i class="far fa-eye"></i></a>
                                   
                                      
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php echo Html::script('melody/js/data-table.js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/admin/sale/index.blade.php ENDPATH**/ ?>