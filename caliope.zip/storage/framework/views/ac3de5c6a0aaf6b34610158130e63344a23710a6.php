
<?php $__env->startSection('meta_description', ''); ?>
<?php $__env->startSection('title', ''); ?>
<?php $__env->startSection('styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!-- breadcrumb area start -->
<div class="breadcrumb-area">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="breadcrumb-wrap">
                    <nav aria-label="breadcrumb">
                        <ul class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item active" aria-current="page">my account</li>
                        </ul>
                    </nav>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- breadcrumb area end -->

<!-- my account wrapper start -->
<div class="my-account-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- My Account Page Start -->
                <div class="myaccount-page-wrapper">
                    <!-- My Account Tab Menu Start -->
                    <div class="row">
                        <div class="col-lg-3 col-md-4">
                            <div class="myaccount-tab-menu nav" role="tablist">
                                <a href="#dashboad"  ><i class="fa fa-dashboard"></i>
                                    Dashboard</a>
                                
                                <a href="<?php echo e(route('web.orders')); ?>" class="<?php echo active_class(route('web.orders')); ?>" ><i class="fa fa-cart-arrow-down"></i>
                                    Pedidos</a>
                                
                                
                                <a href="<?php echo e(route('web.address_edit')); ?>"
                                class="<?php echo active_class(route('web.address_edit')); ?>"
                                ><i class="fa fa-map-marker"></i>
                                    Dirección</a>
                                <a href="<?php echo e(route('web.account_info')); ?>"
                                class="<?php echo active_class(route('web.account_info')); ?>"
                                ><i class="fa fa-user"></i> Detalles de la cuenta</a>
                                <a 
                                class="<?php echo active_class(route('web.change_password')); ?>"
                                href="<?php echo e(route('web.change_password')); ?>" ><i class="fa fa-credit-card"></i>
                                    Cambiar Contraseña</a>
                                <a href="<?php echo e(route('logout')); ?>"
                                onclick="event.preventDefault();
                                                document.getElementById('logout-form').
                                                submit();"><i class="fa fa-sign-out"></i> 
                                                Cerrar Sesión</a>
                                
                            </div>
                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" 
                            method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                            </form>
                        </div>
                        <!-- My Account Tab Menu End -->

                        <!-- My Account Tab Content Start -->


                        
                        <?php echo $__env->yieldContent('content_tab'); ?>

                        
                        <!-- My Account Tab Content End -->
                    </div>
                </div> <!-- My Account Page End -->
            </div>
        </div>
    </div>
</div>
<!-- my account wrapper end -->

<!-- brand area start -->
<div class="brand-area pt-34 pb-30">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <div class="section-title mb-30">
                    <div class="title-icon">
                        <i class="fa fa-crop"></i>
                    </div>
                    <h3>Popular Brand</h3>
                </div> <!-- section title end -->
            </div>
        </div>
        <div class="row">
            <div class="col-12">
                <div class="brand-active slick-padding slick-arrow-style">
                    <div class="brand-item text-center">
                        <a href="#"><img src="galio/assets/img/brand/br1.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="galio/assets/img/brand/br2.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="galio/assets/img/brand/br3.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="galio/assets/img/brand/br4.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="galio/assets/img/brand/br5.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="galio/assets/img/brand/br6.png" alt=""></a>
                    </div>
                    <div class="brand-item text-center">
                        <a href="#"><img src="galio/assets/img/brand/br4.png" alt=""></a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- brand area end -->

<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.web', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/my_account.blade.php ENDPATH**/ ?>