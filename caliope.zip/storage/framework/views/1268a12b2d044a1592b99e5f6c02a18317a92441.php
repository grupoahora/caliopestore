<div class="header-mini-cart mt-0 alto">
    <div class="mini-cart-btn">
        <i class="fa fa-shopping-cart"></i>
        <?php if($shopping_cart->quantity_of_products() != 0): ?>
            <span class="cart-notification"><?php echo e($shopping_cart->quantity_of_products()); ?></span>
        <?php endif; ?>
        
    </div>
    <div class="cart-total-price">
        <span>total</span>
        $<?php echo e($shopping_cart->total_price()); ?>

    </div>
    <ul class="cart-list">
        <?php $__currentLoopData = $shopping_cart->shopping_cart_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shopping_cart_detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <div class="cart-img">
                    <a href="product-details.html"><img src="<?php echo e($shopping_cart_detail->product->images->pluck('url')[0]); ?>" alt="<?php echo e($shopping_cart_detail->product->name); ?>"></a>
                </div>
                <div class="cart-info">
                    <h4><a href="product-details.html"><?php echo e($shopping_cart_detail->product->name); ?></a></h4>
                    <span>$<?php echo e($shopping_cart_detail->product->sell_price); ?></span>
                </div>
                <div class="del-icon">
                    <i class="fa fa-times"></i>
                </div>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        
        <li class="mini-cart-price">
            <span class="subtotal">subtotal : </span>
            <span class="subtotal-price">$<?php echo e($shopping_cart->total_price()); ?></span>
        </li>
        <li class="checkout-btn">
            <a href="<?php echo e(route('web.checkout')); ?>">checkout</a>
        </li>
    </ul>
</div>
<?php /**PATH C:\xampp\htdocs\caliope\resources\views/layouts/_mini_cart.blade.php ENDPATH**/ ?>