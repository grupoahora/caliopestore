
<?php $__env->startSection('content_tab'); ?>
<div class="col-lg- col-md-8">
    

    

    <!-- Single Tab Content Start -->
    
    <!-- Single Tab Content End -->

    <!-- Single Tab Content Start -->
    <div class="myaccount-content">
        <h3>Account Details</h3>
        <div class="account-details-form">
            <?php echo Form::model($user,['route'=>['web.update_client', $user], 'method'=>'PUT']); ?>

                <div class="row">
                    <div class="col-lg-6">
                        <div class="single-input-item">
                            <label for="name" class="required">Nombre</label>
                            <input type="text" id="name" name="name" 
                            value="<?php echo e(old('name', $user->name )); ?>" 
                            placeholder="Nombre" required />
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="single-input-item">
                            <label for="surname" class="required">Apellido</label>
                            <input type="text" id="surname" name="surname" 
                            value="<?php echo e(old('surname', $user->surname )); ?>"  
                            placeholder="Apellido" required />
                        </div>
                    </div>
                </div>
                <div class="single-input-item">
                    <label for="email" class="required">Correo Electrónico</label>
                    <input type="email" id="email" name="email" 
                    value="<?php echo e(old('email', $user->email )); ?>" 
                    placeholder="Correo Electrónico" required />
                </div>
                <div class="row">
                    <div class="col-lg-6">
                        <div class="single-input-item">
                            <label for="dni" class="required">Número de Identificación</label>
                            <input type="number" id="dni" name="dni" 
                            value="<?php echo e(old('dni', $user->profile->dni )); ?>" 
                            placeholder="Número de Identificación" required />
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="single-input-item">
                            <label for="ruc" class="required">Número de RUC</label>
                            <input type="number" id="ruc" name="ruc" 
                            value="<?php echo e(old('ruc', $user->profile->ruc )); ?>" 
                            placeholder="Número de RUC" />
                        </div>
                    </div>
                </div>

                
                <div class="single-input-item">
                    <button class="check-btn sqr-btn ">Guardar Cambios</button>
                </div>
            <?php echo Form::close(); ?>

        </div>
    </div>

    
    
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('web.my_account', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/account_info.blade.php ENDPATH**/ ?>