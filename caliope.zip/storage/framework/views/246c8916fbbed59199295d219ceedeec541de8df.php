<div class="modal" id="quick_view<?php echo e($product->id); ?>">
        <div class="modal-dialog modal-lg modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <!-- product details inner end -->
                    <div class="product-details-inner">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="product-large-slider slick-arrow-style_2 mb-20">
                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="pro-large-img">
                                            <img src="<?php echo e($image->url); ?>" alt="<?php echo e($product->name); ?>" />
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <div class="pro-nav slick-padding2 slick-arrow-style_2">
                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="pro-nav-thumb">
                                            <div class="pro-nav-thumb"><img src="<?php echo e($image->url); ?>" alt="<?php echo e($product->name); ?>" /></div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            </div>
                            <div class="col-lg-7">
                                <div class="product-details-des mt-md-34 mt-sm-34">
                                    <h3><a href="<?php echo e(route('web.product_details', $product)); ?>"><?php echo e($product->name); ?></a></h3>
                                    <div class="ratings">
                                        <input id="input_rate_<?php echo e($product->id); ?>4" name="rate" value="<?php echo e($product->AverageRating); ?>" class="rating-loading">
                                        <div class="pro-review">
                                            <span><?php echo e($product->timesRated()); ?> (<?php echo e(round($product->userAverageRating, 1)); ?>) Calificació(s)</span>
                                        </div>
                                        <?php $__env->startPush('scripts'); ?>
                                            <script>
                                                $(document).ready(function(){
                                                    $('#input_rate_<?php echo e($product->id); ?>4').rating({
                                                        min: 0,
                                                        max: 5,
                                                        theme: 'krajee-fa', 
                                                        displayOnly: true,
                                                        step: 1, 
                                                        language: 'es',
                                                        size: 'xs', 
                                                        stars: 5,
                                                        showCaption: false,
                                                    });
                                                });
                                            </script>
                                        <?php $__env->stopPush(); ?>
                                    </div>
                                    <div class="availability mt-10">
                                        <h5>Availability:</h5>
                                        <span><?php echo e($product->stock); ?> en Inventario</span>
                                    </div>
                                    <div class="pricebox">
                                        <span class="regular-price"> $<?php echo e($product->sell_price); ?></span>
                                    </div>
                                    <p>
                                        <?php echo e($product->short_description); ?>

                                    </p>
                                    
                                    <?php echo $__env->make('web._add_to_shopping_cart_form', ['class'=>' mt-20'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- product details inner end -->
                </div>
            </div>
        </div>
    </div><?php /**PATH C:\xampp\htdocs\caliope\resources\views/web/_modal_quick_view.blade.php ENDPATH**/ ?>